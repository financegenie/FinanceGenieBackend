var firebaseConfig = {
    apiKey: "AIzaSyAnyK0_vSaKmg4h8a56SUHZVv4lNl9Eghs",
    authDomain: "financegenie.firebaseapp.com",
    databaseURL: "https://financegenie.firebaseio.com",
    projectId: "financegenie",
    storageBucket: "financegenie.appspot.com",
    messagingSenderId: "296993871048",
};

module.exports = {
    firebaseConfig
}
